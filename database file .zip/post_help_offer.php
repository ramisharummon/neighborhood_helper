<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offer Help</title>
</head>
<body>

<h2>Offer Help</h2>

<form action="submit_help_offer.php" method="POST">
    <label for="title">Title of Offer:</label>
    <input type="text" id="title" name="title" required><br><br>

    <label for="description">Description:</label>
    <textarea id="description" name="description" required></textarea><br><br>

    <label for="category">Category:</label>
    <select id="category" name="category">
        <option value="Errands">Errands</option>
        <option value="Home Repairs">Home Repairs</option>
        <option value="Pet Care">Pet Care</option>
        <option value="Childcare">Childcare</option>
        <option value="Teaching">Teaching</option>
        <option value="Moving Assistance">Moving Assistance</option>
    </select><br><br>

    <label for="price">Price (Optional):</label>
    <input type="number" id="price" name="price" step="0.01"><br><br>

    <label for="availability">Availability:</label>
    <input type="text" id="availability" name="availability" required><br><br>

    <input type="submit" value="Post Offer">
</form>

</body>
</html>
