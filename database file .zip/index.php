<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neighborhood Helper</title>
</head>
<body>

<h1>Welcome to Neighborhood Helper</h1>
<p>Need help or want to offer help? You are in the right place!</p>

<a href="post_help_request.php">Post a Help Request</a><br>
<a href="post_help_offer.php">Post a Help Offer</a><br>
<a href="browse_help.php">Browse Help Requests and Offers</a><br>

</body>
</html>
