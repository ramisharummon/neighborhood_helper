<?php
// Database connection
include('db_config.php');

// Retrieve form data
$title = $_POST['title'];
$description = $_POST['description'];
$category = $_POST['category'];
$urgency = $_POST['urgency'];
$location = $_POST['location'];
$timeframe = $_POST['timeframe'];
$userID = 1; // Assume user is logged in with ID 1 (adjust accordingly)

// Insert help request into the database
$sql = "INSERT INTO helprequest (UserID, Title, Description, Category, UrgencyLevel, Location, TimeFrame, Status) 
        VALUES ('$userID', '$title', '$description', '$category', '$urgency', '$location', '$timeframe', 'Pending')";

if ($conn->query($sql) === TRUE) {
    echo "Help request posted successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
