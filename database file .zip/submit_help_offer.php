<?php
// Database connection
include('db_config.php');

// Retrieve form data
$title = $_POST['title'];
$description = $_POST['description'];
$category = $_POST['category'];
$price = $_POST['price'];
$availability = $_POST['availability'];
$userID = 1; // Assume user is logged in with ID 1 (adjust accordingly)

// Insert help offer into the database
$sql = "INSERT INTO helpoffer (UserID, Title, Description, Category, Price, Availability, OfferDate, Status) 
        VALUES ('$userID', '$title', '$description', '$category', '$price', '$availability', NOW(), 'Active')";

if ($conn->query($sql) === TRUE) {
    echo "Help offer posted successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
