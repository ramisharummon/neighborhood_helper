<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Help Request</title>
</head>
<body>

<h2>Post a Help Request</h2>

<form action="submit_help_request.php" method="POST">
    <label for="title">Title of Request:</label>
    <input type="text" id="title" name="title" required><br><br>

    <label for="description">Description:</label>
    <textarea id="description" name="description" required></textarea><br><br>

    <label for="category">Category:</label>
    <select id="category" name="category">
        <option value="Errands">Errands</option>
        <option value="Home Repairs">Home Repairs</option>
        <option value="Pet Care">Pet Care</option>
        <option value="Childcare">Childcare</option>
        <option value="Teaching">Teaching</option>
        <option value="Moving Assistance">Moving Assistance</option>
    </select><br><br>

    <label for="urgency">Urgency Level:</label>
    <select id="urgency" name="urgency">
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
        <option value="High">High</option>
    </select><br><br>

    <label for="location">Location:</label>
    <input type="text" id="location" name="location" required><br><br>

    <label for="timeframe">Timeframe:</label>
    <input type="text" id="timeframe" name="timeframe" required><br><br>

    <input type="submit" value="Post Request">
</form>

</body>
</html>
