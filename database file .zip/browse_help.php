<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Help Requests and Offers</title>
</head>
<body>

<h2>Browse Help Requests and Offers</h2>

<form action="browse_help.php" method="GET">
    <label for="category">Category:</label>
    <select id="category" name="category">
        <option value="Errands">Errands</option>
        <option value="Home Repairs">Home Repairs</option>
        <option value="Pet Care">Pet Care</option>
        <option value="Childcare">Childcare</option>
        <option value="Teaching">Teaching</option>
        <option value="Moving Assistance">Moving Assistance</option>
    </select><br><br>

    <label for="location">Location:</label>
    <input type="text" id="location" name="location"><br><br>

    <label for="urgency">Urgency Level:</label>
    <select id="urgency" name="urgency">
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
        <option value="High">High</option>
    </select><br><br>

    <input type="submit" value="Filter">
</form>

<?php
// Database connection
include('db_config.php');

// Fetch filtered data based on user input
$category = isset($_GET['category']) ? $_GET['category'] : '';
$location = isset($_GET['location']) ? $_GET['location'] : '';
$urgency = isset($_GET['urgency']) ? $_GET['urgency'] : '';

$sql = "SELECT * FROM helpoffer WHERE Category LIKE '%$category%' AND Location LIKE '%$location%' AND Status = 'Active'";

if ($urgency) {
    $sql .= " AND UrgencyLevel = '$urgency'";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "Title: " . $row["Title"]. " - Description: " . $row["Description"]. " - Category: " . $row["Category"]. "<br>";
    }
} else {
    echo "No results found.";
}

$conn->close();
?>

</body>
</html>
